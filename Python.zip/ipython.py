import pandas
import IPython

df1 = pandas.DataFrame([[2,4,6],[5,9,11]], columns = ["Price","Age","Position"], index = ["1St","2nd"])
print(df1)
df2 = pandas.DataFrame([{"Name":"Smirti", "Surname":"Barnwal"},{"Name":"Saroj", "Surname":"Barnwal"}])
print(df2)

print(type(df1))

print(df1.mean())

print(type(df1.mean()))
n= df1.mean().mean()
print(n)

print(df1.Price)
print("price mean : " , df1.Price.mean())
print("price max : ",df1.Price.max())