import json
import difflib

from difflib import get_close_matches

data = json.load(open("data.json"))

def translate(word):
    word = word.lower()
    if word in data:
        return data[word]

    elif word.title() in data:
        return data[word.title()]

    elif word.upper() in data :
        return data[word.upper()]

    elif len(get_close_matches(word,data.keys())) >0:
        yn = input("Did YOu mean %s instead ? Enter Y for yes and N for No : " %get_close_matches(word,data.keys())[0] )

        if yn == 'Y':
            return data[get_close_matches(word,data.keys())[0]]

        elif yn == 'N':
             return "Word does'nt exists...Please Double Check it"

        else :
            return "We did'nt understand your entry..."

    else :
        return "Word does'nt exists...Please Double Check it"

w = input("Enter word : ")

output = translate(w)
if type(output) == list :
    for item in output:
        print(item)
else:
    print(output)